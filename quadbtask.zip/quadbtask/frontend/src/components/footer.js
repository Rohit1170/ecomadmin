import React from 'react';
const Footer=()=>{
    return(
        <div className="footer">
            <h2>E-Dashboard</h2>
        </div>
    )}
export default Footer;