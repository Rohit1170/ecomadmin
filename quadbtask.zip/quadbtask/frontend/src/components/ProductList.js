import React, { useEffect, useState } from 'react';
import {Link} from 'react-router-dom';
import './ProductList.css';
const ProductList = () => {
    const [products, setProducts] = useState([]);

    useEffect(() => {
        getProducts();
    }, []);

    const getProducts = async () => {
        let result = await fetch("http://localhost:5000/products",
        {
            headers:{
                authorization:`bearer ${JSON.parse(localStorage.getItem('token'))}`
            }
        });
        result = await result.json();
        setProducts(result);
    }

    const deleteProduct = async (id)=>{
        let result = await fetch(`http://localhost:5000/product/${id}`,{
            method:"Delete",
            headers:{
                authorization:`bearer ${JSON.parse(localStorage.getItem('token'))}`
            }
        });
        result = await result.json();
        if(result)
        {
            console.log(result);
            alert("Deleted");
            getProducts();

        }
        

    }

    const searchHandel=async (event)=>{
        console.warn(event.target.value)
        const key = event.target.value;
        if(key){
        let result  = await fetch(`http://localhost:5000/search/${key}`,
        {
            headers:{
                authorization:`bearer ${JSON.parse(localStorage.getItem('token'))}`
            }
        })
        result = await result.json();

        if(result)
        {
            setProducts(result);
        }
    }

    else{
        getProducts();
    }
    }
    



    return (
        <div className="Product-list">
        <h3>Product List</h3>
        <input type="text" className='search' placeholder='Search' onChange={searchHandel} />
        <div className="row">
            {products.length > 0 ? (
                products.map((item, index) => (
                    <div key={item._id} className="col-md-4 mb-3">
                        <div className="card">
                            <div className="card-body">
                                <h5 className="card-title">{item.name}</h5>
                                <p className="card-text">
                                    <strong>Price:</strong> ${item.price}<br />
                                    <strong>Category:</strong> {item.category}<br />
                                    <strong>Company:</strong> {item.company}
                                </p>
                                <div className="card-links">
                                    <button onClick={() => deleteProduct(item._id)} className="btn btn-danger mr-2">Delete</button>
                                    <Link to={"/update/" + item._id} className="btn btn-primary">Update</Link>
                                </div>
                            </div>
                        </div>
                    </div>
                ))
            ) : (
                <h1>No results found</h1>
            )}
        </div>
    </div>
    )
}

export default ProductList;
